	<footer id="footer">
		<div class="container">
			<div class="row">
				<div class="col">
					<p class="address text-center">
					โรงเรียนเทพศิรินทร์ร่มเกล้า เลขที่ 2 ซอย ไอซีดี 8 แขวงคลองสามประเวศ เขตลาดกระบัง กรุงเทพมหานคร 10520 <i class="fa fa-phone" aria-hidden="true"></i> โทรศัพท์ 0 2737 8919 - 20 <i class="fa fa-fax" aria-hidden="true"></i> โทรสาร 0 2360 9287
					</p>
				</div>
			</div>
		</div>
	</footer>